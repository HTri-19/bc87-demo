function Navbar(){
    return (
        <div className="navbar">Navbar Component</div>
    )
}

export default Navbar