function Footer(){
    return (
        <div className="footer">Footer Component</div>
    )
}

export default Footer