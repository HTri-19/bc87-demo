import "./header.css";

function Header(){
    return (
        <div className="header">Header Component</div>
    )
}

export default Header