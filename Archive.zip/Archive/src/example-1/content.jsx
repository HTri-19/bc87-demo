function Content() {
  return <div className="content">Content Component</div>;
}

export default Content;
