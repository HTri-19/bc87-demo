import "./App.css";
// import Example1 from "./example-1";
import Example2 from "./example-2";

function App() {
  return (
    <>
      <h1>Learn Reactjs</h1>
      {/* <Example1 /> */}
      <Example2 />
    </>
  );
}

export default App;
