/** //Bài 1: Quản lý tuyển sinh
 * 
    *  Đầu vào:
    diemChuan – điểm chuẩn nhập từ input.

    khuVuc – khu vực ưu tiên (A/B/C/X).

    doiTuong – đối tượng ưu tiên (1/2/3/0).

    mon1, mon2, mon3 – điểm 3 môn thi.

    * Xử lý:
    Kiểm tra nếu có môn nào 0 điểm → rớt luôn.

    Tính điểm ưu tiên khu vực + đối tượng.

    Cộng tổng điểm 3 môn + điểm ưu tiên.

    So sánh với diemChuan → quyết định đậu/rớt.

    * Đầu ra:
    Xuất kết quả: “Đậu” hoặc “Rớt” và tổng điểm.
 */

function tinhKetQua() {
  const diemChuan = Number(document.getElementById("diemChuan").value);
  const khuVuc = document.getElementById("khuVuc").value;
  const doiTuong = document.getElementById("doiTuong").value;
  const mon1 = Number(document.getElementById("mon1").value);
  const mon2 = Number(document.getElementById("mon2").value);
  const mon3 = Number(document.getElementById("mon3").value);
  let ketQua = "";

  // Kiểm tra điểm 0
  if (mon1 === 0 || mon2 === 0 || mon3 === 0) {
    ketQua = "Rớt do có môn 0 điểm.";
  } else {
    // Điểm ưu tiên khu vực
    let diemKhuVuc = 0;
    if (khuVuc === "A") diemKhuVuc = 2;
    else if (khuVuc === "B") diemKhuVuc = 1;
    else if (khuVuc === "C") diemKhuVuc = 0.5;

    // Điểm ưu tiên đối tượng
    let diemDoiTuong = 0;
    if (doiTuong === "1") diemDoiTuong = 2.5;
    else if (doiTuong === "2") diemDoiTuong = 1.5;
    else if (doiTuong === "3") diemDoiTuong = 1;

    const tongDiem = mon1 + mon2 + mon3 + diemKhuVuc + diemDoiTuong;

    ketQua =
      tongDiem >= diemChuan
        ? `Đậu. Tổng điểm: ${tongDiem}`
        : `Rớt. Tổng điểm: ${tongDiem}`;
  }

  document.getElementById("ketQua").innerText = ketQua;
}

// Bài 2 : Tính tiền điện
/**
     *  Đầu vào:
    tenKH – tên khách hàng.

    soKw – số điện tiêu thụ.

    * Xử lý:
    Tính tiền theo từng bậc thang giá điện:

    0–50 kWh: 500 đ/kWh

    51–100: 650 đ/kWh

    101–200: 850 đ/kWh

    201–350: 1100 đ/kWh

    350: 1300 đ/kWh

    Cộng dồn tiền từng bậc.
    * Đầu ra:
    Xuất: Tên khách hàng + Tiền điện phải trả (VNĐ).


 * 
 */

function tinhTienDien() {
  // Khối input
  const ten = document.getElementById("tenKH").value;
  const kw = parseFloat(document.getElementById("soKw").value);

  // Khối xử lý
  let tongTien = 0;
  let kwConLai = kw;

  if (kwConLai <= 0 || isNaN(kw)) {
    document.getElementById("ketQuaDien").innerText =
      "Vui lòng nhập số Kw hợp lệ.";
    return;
  }

  if (kwConLai > 0) {
    const bac1 = Math.min(kwConLai, 50);
    tongTien += bac1 * 500;
    kwConLai -= bac1;
  }

  if (kwConLai > 0) {
    const bac2 = Math.min(kwConLai, 50);
    tongTien += bac2 * 650;
    kwConLai -= bac2;
  }

  if (kwConLai > 0) {
    const bac3 = Math.min(kwConLai, 100);
    tongTien += bac3 * 850;
    kwConLai -= bac3;
  }

  if (kwConLai > 0) {
    const bac4 = Math.min(kwConLai, 150);
    tongTien += bac4 * 1100;
    kwConLai -= bac4;
  }

  if (kwConLai > 0) {
    tongTien += kwConLai * 1300;
  }

  // Khối output
  document.getElementById(
    "ketQuaDien"
  ).innerText = `Khách hàng: ${ten}\nTiền điện phải trả: ${tongTien.toLocaleString()} VNĐ`;
}

// Bài 3 : Tính thuế thu nhập cá nhân
/**
     * Đầu vào:
    hoTen – họ tên cá nhân.

    tongThuNhap – tổng thu nhập năm (triệu).

    soNguoiPhuThuoc – số người phụ thuộc.

    * Xử lý:
    Tính thu nhập chịu thuế:
    thuNhapChiuThue = tongThuNhap - 4 - (soNguoiPhuThuoc * 1.6)

    Dựa vào mức thu nhập → tính thuế theo thuế suất:

    ≤ 60 → 5%

    ≤ 120 → 10%

    ≤ 210 → 15%

    ≤ 384 → 20%

    ≤ 624 → 25%

    ≤ 960 → 30%

    960 → 35%

    * Đầu ra:
    Xuất: Tên + Thuế phải trả (triệu VNĐ).
 * 
 */
function tinhThue() {
  const hoTen = document.getElementById("hoTen").value;
  const tongThuNhap = parseFloat(document.getElementById("tongThuNhap").value);
  const soNguoiPhuThuoc = parseInt(
    document.getElementById("soNguoiPhuThuoc").value
  );

  if (!hoTen || isNaN(tongThuNhap) || isNaN(soNguoiPhuThuoc)) {
    document.getElementById("ketQuaThue").innerText =
      "Vui lòng nhập đầy đủ thông tin hợp lệ.";
    return;
  }

  const thuNhapChiuThue = tongThuNhap - 4 - soNguoiPhuThuoc * 1.6;
  let thue = 0;

  if (thuNhapChiuThue <= 0) {
    thue = 0;
  } else if (thuNhapChiuThue <= 60) {
    thue = thuNhapChiuThue * 0.05;
  } else if (thuNhapChiuThue <= 120) {
    thue = thuNhapChiuThue * 0.1;
  } else if (thuNhapChiuThue <= 210) {
    thue = thuNhapChiuThue * 0.15;
  } else if (thuNhapChiuThue <= 384) {
    thue = thuNhapChiuThue * 0.2;
  } else if (thuNhapChiuThue <= 624) {
    thue = thuNhapChiuThue * 0.25;
  } else if (thuNhapChiuThue <= 960) {
    thue = thuNhapChiuThue * 0.3;
  } else {
    thue = thuNhapChiuThue * 0.35;
  }

  document.getElementById(
    "ketQuaThue"
  ).innerText = `Họ tên: ${hoTen}\nThuế phải trả: ${thue.toLocaleString()} triệu VNĐ`;
}

// Ẩn/hiện ô kết nối
function hienKetNoi() {
  const loaiKH = document.getElementById("loaiKH").value;
  const soKetNoiWrapper = document.getElementById("soKetNoiWrapper");
  if (loaiKH === "DN") {
    soKetNoiWrapper.style.display = "block";
  } else {
    soKetNoiWrapper.style.display = "none";
  }
}

// Bài 4: Tính tiền cáp
/**
 *  Đầu vào:
    maKH – mã khách hàng.

    loaiKH – loại khách hàng (ND hoặc DN).

    soKetNoi – số kết nối (chỉ hiện nếu là DN).

    soKenh – số kênh cao cấp.

    * Xử lý:
    Nếu là nhà dân (ND):

    Xử lý hóa đơn: 4.5$

    Dịch vụ cơ bản: 20.5$

    Kênh cao cấp: 7.5$/kênh

    Nếu là doanh nghiệp (DN):

    Xử lý hóa đơn: 15$

    Dịch vụ cơ bản: 75$ cho 10 kết nối đầu

    5$/kết nối thêm

    Kênh cao cấp: 50$/kênh

    * Đầu ra:
    Xuất: Mã khách hàng + Tiền cáp phải trả (USD).
 * 
 */
function tinhTienCap() {
  const maKH = document.getElementById("maKH").value;
  const loaiKH = document.getElementById("loaiKH").value;
  const soKetNoi = parseInt(document.getElementById("soKetNoi").value) || 0;
  const soKenh = parseInt(document.getElementById("soKenh").value);

  if (!maKH || !loaiKH || isNaN(soKenh)) {
    document.getElementById("ketQuaCap").innerText =
      "Vui lòng nhập đầy đủ thông tin.";
    return;
  }

  let tongTien = 0;

  if (loaiKH === "ND") {
    tongTien = 4.5 + 20.5 + soKenh * 7.5;
  } else if (loaiKH === "DN") {
    let phiKetNoi = 75;
    if (soKetNoi > 10) {
      phiKetNoi += (soKetNoi - 10) * 5;
    }
    tongTien = 15 + phiKetNoi + soKenh * 50;
  }

  document.getElementById(
    "ketQuaCap"
  ).innerText = `Mã KH: ${maKH}\nTiền cáp phải trả: $${tongTien.toFixed(2)}`;
}

// Gọi lần đầu để ẩn ô kết nối
window.onload = hienKetNoi;
