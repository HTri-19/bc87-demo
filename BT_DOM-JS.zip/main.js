//Này là file JS sau khi làm đã gộp chung , mô hình 3 khối nằm ở mỗi file riêng , em để như vậy cho tiện chấm !


// ==========================
// Bài 1: Tính tiền lương
// ==========================
function tinhLuong() {
  const luongNgay = parseFloat(document.getElementById("luongNgay").value);
  const soNgay = parseInt(document.getElementById("soNgay").value);

  if (isNaN(luongNgay) || isNaN(soNgay)) {
    alert("Vui lòng nhập đầy đủ và đúng định dạng.");
    return;
  }

  const tongLuong = luongNgay * soNgay;
  const ketQuaDiv = document.getElementById("ketqua");
  ketQuaDiv.innerHTML = `Tổng lương bạn nhận được là: <strong>${tongLuong.toLocaleString()} VND</strong>`;
}

document.getElementById("salaryForm").addEventListener("submit", function (e) {
  e.preventDefault();
  tinhLuong();
});


// ==========================
// Bài 2: Tính giá trị trung bình
// ==========================
function tinhGiaTriTrungBinh() {
  const n1 = parseFloat(document.getElementById("num1").value);
  const n2 = parseFloat(document.getElementById("num2").value);
  const n3 = parseFloat(document.getElementById("num3").value);
  const n4 = parseFloat(document.getElementById("num4").value);
  const n5 = parseFloat(document.getElementById("num5").value);

  if ([n1, n2, n3, n4, n5].some(isNaN)) {
    alert("Vui lòng nhập đúng tất cả 5 số!");
    return;
  }

  const avg = (n1 + n2 + n3 + n4 + n5) / 5;
  document.getElementById("result").innerText = `Giá trị trung bình là: ${avg}`;
}

document.getElementById("avgForm").addEventListener("submit", function (e) {
  e.preventDefault();
  tinhGiaTriTrungBinh();
});


// ==========================
// Bài 3: Quy đổi USD sang VNĐ
// ==========================
document.getElementById("usdForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const usd = parseFloat(document.getElementById("usdAmount").value);
  if (isNaN(usd) || usd <= 0) {
    document.getElementById("vndResult").innerText = "Vui lòng nhập số USD hợp lệ.";
    return;
  }

  const rate = 23500;
  const vnd = usd * rate;
  const formatted = new Intl.NumberFormat("vi-VN").format(vnd);

  document.getElementById("vndResult").innerText = `${usd} USD = ${formatted} VNĐ`;
});


// ==========================
// Bài 4: Diện tích & Chu vi HCN
// ==========================
document.getElementById("rectangleForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const dai = parseFloat(document.getElementById("chieudai").value);
  const rong = parseFloat(document.getElementById("chieurong").value);

  if (isNaN(dai) || isNaN(rong) || dai <= 0 || rong <= 0) {
    document.getElementById("hcnResult").innerText = "Vui lòng nhập chiều dài và chiều rộng hợp lệ.";
    return;
  }

  const dientich = dai * rong;
  const chuvi = 2 * (dai + rong);

  document.getElementById("hcnResult").innerText =
    `Diện tích: ${dientich} \nChu vi: ${chuvi}`;
});


// ==========================
// Bài 5: Tổng 2 chữ số
// ==========================
document.getElementById("sum2digitsForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const number = parseInt(document.getElementById("twoDigitInput").value);

  if (isNaN(number) || Math.abs(number) < 10 || Math.abs(number) > 99) {
    document.getElementById("sum2digitsResult").innerText = "Vui lòng nhập một số có đúng 2 chữ số.";
    return;
  }

  const absNumber = Math.abs(number);
  const hangChuc = Math.floor(absNumber / 10);
  const hangDonVi = absNumber % 10;
  const tong = hangChuc + hangDonVi;

  document.getElementById("sum2digitsResult").innerText =
    `Tổng hai chữ số của ${number} là: ${tong}`;
});
