//Bài 2 : Tính giá trị trung bình
/**
 * Tính giá trị trung bình 
 *
 *  Đầu vào:
 *  - Nhập 5 số: num1 → num5
 *
 *  Xử lý:
 *  - Ép kiểu sang float
 *  - Kiểm tra tất cả phải là số hợp lệ
 *  - Tính trung bình: avg = (n1 + n2 + n3 + n4 + n5) / 5
 *
 *  Đầu ra:
 *  - In ra giá trị trung bình
 */

function tinhGiaTriTrungBinh() {
  // Lấy và ép kiểu dữ liệu
  const n1 = parseFloat(document.getElementById("num1").value);
  const n2 = parseFloat(document.getElementById("num2").value);
  const n3 = parseFloat(document.getElementById("num3").value);
  const n4 = parseFloat(document.getElementById("num4").value);
  const n5 = parseFloat(document.getElementById("num5").value);

  // Kiểm tra hợp lệ
  if ([n1, n2, n3, n4, n5].some(isNaN)) {
    alert("Vui lòng nhập đúng tất cả 5 số!");
    return;
  }

  // Tính trung bình
  const avg = (n1 + n2 + n3 + n4 + n5) / 5;

  // Hiển thị kết quả
  document.getElementById("result").innerText =
    `Giá trị trung bình là: ${avg}`;
}

document.getElementById("avgForm").addEventListener("submit", function(e) {
  e.preventDefault();  // Ngăn reload trang
  tinhGiaTriTrungBinh();
});
