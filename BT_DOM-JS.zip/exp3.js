// Bài 3: Quy đổi USD sang VNĐ
/**
 *  Quy đổi tiền USD sang VNĐ
 *
 *  Đầu vào:
 *  - Nhập số tiền USD
 *
 *  Xử lý:
 *  - Tỉ giá cố định: 1 USD = 23500 VNĐ
 *  - Kiểm tra số dương hợp lệ
 *  - Tính vnd = usd * 23500
 *  - Format kết quả theo VN
 *
 *  Đầu ra:
 *  - In ra số tiền VNĐ sau quy đổi
 */


// Bắt sự kiện submit form
document.getElementById("usdForm").addEventListener("submit", function (e) {
  e.preventDefault(); // Ngăn form reload trang

  // Lấy giá trị USD từ input
  const usd = parseFloat(document.getElementById("usdAmount").value);

  // Kiểm tra đầu vào
  if (isNaN(usd) || usd <= 0) {
    document.getElementById("vndResult").innerText = "Vui lòng nhập số USD hợp lệ.";
    return;
  }
  const rate = 23500;
  const vnd = usd * rate;
  const formatted = new Intl.NumberFormat("vi-VN").format(vnd);
  document.getElementById("vndResult").innerText = `${usd} USD = ${formatted} VNĐ`;
});
