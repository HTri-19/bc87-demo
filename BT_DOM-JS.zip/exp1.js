//Bài 1 : Tính tiền lương 
/**
 *  Tính tiền lương = lương/ngày × số ngày làm
 *
 *  Đầu vào:
 *  - Nhập lương 1 ngày (luongNgay)
 *  - Nhập số ngày làm (soNgay)
 *
 * Xử lý:
 *  - Kiểm tra định dạng số
 *  - Tính tổng lương: tongLuong = luongNgay * soNgay
 *  - Format kết quả bằng toLocaleString
 *
 *  Đầu ra:
 *  - In ra tổng lương định dạng VND
 */


function tinhLuong() {
  const luongNgay = parseFloat(document.getElementById("luongNgay").value);
  const soNgay = parseInt(document.getElementById("soNgay").value);

  if (isNaN(luongNgay) || isNaN(soNgay)) {
    alert("Vui lòng nhập đầy đủ và đúng định dạng.");
    return;
  }

  const tongLuong = luongNgay * soNgay;
  const ketQuaDiv = document.getElementById("ketqua");
  ketQuaDiv.innerHTML = `Tổng lương bạn nhận được là: <strong>${tongLuong.toLocaleString()} VND</strong>`;
}

// Gắn sự kiện vào form (ngăn reload trang)
document.getElementById("salaryForm").addEventListener("submit", function (e) {
  e.preventDefault(); // ngăn load lại trang
  tinhLuong();
});
