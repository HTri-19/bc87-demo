// Bài 4: Tính diện tích và chu vi hình chữ nhật
/**
 * Tính diện tích và chu vi hình chữ nhật
 *
 * Đầu vào:
 *  - Nhập chiều dài (chieudai)
 *  - Nhập chiều rộng (chieurong)
 *
 *  Xử lý:
 *  - Kiểm tra > 0
 *  - Diện tích: dientich = dài * rộng
 *  - Chu vi: chuvi = 2 * (dài + rộng)
 *
 * Đầu ra:
 *  - In ra diện tích và chu vi
 */


// Bắt sự kiện submit form
document.getElementById("rectangleForm").addEventListener("submit", function (e) {
  e.preventDefault(); // Ngăn form reload trang

  // Lấy dữ liệu từ input
  const dai = parseFloat(document.getElementById("chieudai").value);
  const rong = parseFloat(document.getElementById("chieurong").value);

  // Kiểm tra hợp lệ
  if (isNaN(dai) || isNaN(rong) || dai <= 0 || rong <= 0) {
    document.getElementById("hcnResult").innerText = "Vui lòng nhập chiều dài và chiều rộng hợp lệ.";
    return;
  }

  // Tính diện tích và chu vi
  const dientich = dai * rong;
  const chuvi = 2 * (dai + rong);
  document.getElementById("hcnResult").innerText =
    `Diện tích: ${dientich} \nChu vi: ${chuvi} `;
});
