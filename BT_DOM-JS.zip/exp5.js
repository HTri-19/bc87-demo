// Bài 5: Tính tổng 2 chữ số
/**
 * Tính tổng 2 chữ số của số có 2 chữ số
 *
 * Đầu vào:
 *  - Nhập số có 2 chữ số 
 *
 *  Xử lý:
 *  - Lấy giá trị tuyệt đối
 *  - Hàng chục: Math.floor(abs / 10)
 *  - Hàng đơn vị: abs % 10
 *  - Tổng = hàng chục + hàng đơn vị
 *
 *  Đầu ra:
 *  - In ra tổng 2 chữ số
 */


document.getElementById("sum2digitsForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const number = parseInt(document.getElementById("twoDigitInput").value);

  // Kiểm tra số hợp lệ là 2 chữ số (10 - 99 hoặc -99 đến -10)
  if (isNaN(number) || Math.abs(number) < 10 || Math.abs(number) > 99) {
    document.getElementById("sum2digitsResult").innerText =
      "Vui lòng nhập một số có đúng 2 chữ số.";
    return;
  }

  const absNumber = Math.abs(number); // lấy giá trị dương nếu là số âm
  const hangChuc = Math.floor(absNumber / 10);
  const hangDonVi = absNumber % 10;
  const tong = hangChuc + hangDonVi;

  document.getElementById("sum2digitsResult").innerText =
    `Tổng hai chữ số của ${number} là: ${tong}`;
});
