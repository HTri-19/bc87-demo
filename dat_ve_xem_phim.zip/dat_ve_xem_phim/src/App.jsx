import BaiTapBookingTicket from './components/BaiTapBookingTicket'
import './App.css'

function App() {
  return (
    <div className="App">
      <BaiTapBookingTicket />
    </div>
  )
}

export default App
