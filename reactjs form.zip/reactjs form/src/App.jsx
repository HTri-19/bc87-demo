import './App.css'
import StudentForm from './components/StudentForm'
import StudentTable from './components/StudentTable'
import SearchBar from './components/SearchBar'

function App() {
  return (
    <div className="app">
      <div className="container">
        <h1>Quản lý sinh viên</h1>
        
        <StudentForm />
        
        <div className="student-list-section">
          <h2>Danh sách sinh viên</h2>
          <SearchBar />
          <StudentTable />
        </div>
      </div>
    </div>
  )
}

export default App
