import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  students: [
    {
      id: 1,
      maSV: '1',
      hoTen: 'Nguyen Van A',
      soDienThoai: '0981111111',
      email: 'nguyenvana@gmail.com',
    },
    {
      id: 2,
      maSV: '2',
      hoTen: 'Nguyen Van B',
      soDienThoai: '0982222222',
      email: 'nguyenvanb@gmail.com',
    },
  ],
  editingStudent: null,
  searchTerm: '',
  nextId: 3,
};

export const studentSlice = createSlice({
  name: 'students',
  initialState,
  reducers: {
    addStudent: (state, action) => {
      const newStudent = {
        id: state.nextId,
        ...action.payload,
      };
      state.students.push(newStudent);
      state.nextId += 1;
    },
    updateStudent: (state, action) => {
      const index = state.students.findIndex(
        (student) => student.id === action.payload.id
      );
      if (index !== -1) {
        state.students[index] = action.payload;
      }
      state.editingStudent = null;
    },
    deleteStudent: (state, action) => {
      state.students = state.students.filter(
        (student) => student.id !== action.payload
      );
    },
    setEditingStudent: (state, action) => {
      state.editingStudent = action.payload;
    },
    clearEditingStudent: (state) => {
      state.editingStudent = null;
    },
    setSearchTerm: (state, action) => {
      state.searchTerm = action.payload;
    },
  },
});

export const {
  addStudent,
  updateStudent,
  deleteStudent,
  setEditingStudent,
  clearEditingStudent,
  setSearchTerm,
} = studentSlice.actions;

export default studentSlice.reducer;
