import { useDispatch, useSelector } from 'react-redux'
import { setSearchTerm } from '../store/studentSlice'

const SearchBar = () => {
  const dispatch = useDispatch()
  const searchTerm = useSelector(state => state.students.searchTerm)

  const handleSearchChange = (e) => {
    dispatch(setSearchTerm(e.target.value))
  }

  const clearSearch = () => {
    dispatch(setSearchTerm(''))
  }

  return (
    <div className="search-bar">
      <div className="search-input-group">
        <input
          type="text"
          placeholder="Tìm kiếm sinh viên (mã SV, họ tên, số điện thoại, email)..."
          value={searchTerm}
          onChange={handleSearchChange}
          className="search-input"
        />
        {searchTerm && (
          <button 
            type="button" 
            className="clear-search"
            onClick={clearSearch}
            title="Xóa tìm kiếm"
          >
            ✕
          </button>
        )}
      </div>
    </div>
  )
}

export default SearchBar
