import { useState, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { addStudent, updateStudent, clearEditingStudent } from '../store/studentSlice'

const StudentForm = () => {
  const dispatch = useDispatch()
  const editingStudent = useSelector(state => state.students.editingStudent)
  
  const [formData, setFormData] = useState({
    maSV: '',
    hoTen: '',
    soDienThoai: '',
    email: ''
  })
  
  const [errors, setErrors] = useState({})

  // Lifecycle: Load data when editing
  useEffect(() => {
    if (editingStudent) {
      setFormData({
        maSV: editingStudent.maSV,
        hoTen: editingStudent.hoTen,
        soDienThoai: editingStudent.soDienThoai,
        email: editingStudent.email
      })
    } else {
      setFormData({
        maSV: '',
        hoTen: '',
        soDienThoai: '',
        email: ''
      })
    }
    setErrors({})
  }, [editingStudent])

  const validateForm = () => {
    const newErrors = {}
    
    // Validate Mã SV
    if (!formData.maSV.trim()) {
      newErrors.maSV = 'Mã sinh viên không được để trống'
    } else if (!/^\d+$/.test(formData.maSV.trim())) {
      newErrors.maSV = 'Mã sinh viên phải là số'
    }
    
    // Validate Họ tên
    if (!formData.hoTen.trim()) {
      newErrors.hoTen = 'Họ tên không được để trống'
    } else if (formData.hoTen.trim().length < 2) {
      newErrors.hoTen = 'Họ tên phải có ít nhất 2 ký tự'
    }
    
    // Validate Số điện thoại
    if (!formData.soDienThoai.trim()) {
      newErrors.soDienThoai = 'Số điện thoại không được để trống'
    } else if (!/^\d{10,11}$/.test(formData.soDienThoai.trim())) {
      newErrors.soDienThoai = 'Số điện thoại phải có 10-11 chữ số'
    }
    
    // Validate Email
    if (!formData.email.trim()) {
      newErrors.email = 'Email không được để trống'
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Email không đúng định dạng'
    }
    
    return newErrors
  }

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }))
    }
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    
    const validationErrors = validateForm()
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors)
      return
    }

    if (editingStudent) {
      dispatch(updateStudent({
        ...editingStudent,
        ...formData
      }))
    } else {
      dispatch(addStudent(formData))
    }
    
    // Reset form
    setFormData({
      maSV: '',
      hoTen: '',
      soDienThoai: '',
      email: ''
    })
    setErrors({})
  }

  const handleCancel = () => {
    dispatch(clearEditingStudent())
    setFormData({
      maSV: '',
      hoTen: '',
      soDienThoai: '',
      email: ''
    })
    setErrors({})
  }

  return (
    <div className="student-form">
      <h2>Thông tin sinh viên</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-row">
          <div className="form-group">
            <label htmlFor="maSV">Mã SV</label>
            <input
              type="text"
              id="maSV"
              name="maSV"
              value={formData.maSV}
              onChange={handleChange}
              className={errors.maSV ? 'error' : ''}
            />
            {errors.maSV && <span className="error-message">{errors.maSV}</span>}
          </div>
          
          <div className="form-group">
            <label htmlFor="hoTen">Họ tên</label>
            <input
              type="text"
              id="hoTen"
              name="hoTen"
              value={formData.hoTen}
              onChange={handleChange}
              className={errors.hoTen ? 'error' : ''}
            />
            {errors.hoTen && <span className="error-message">{errors.hoTen}</span>}
          </div>
        </div>
        
        <div className="form-row">
          <div className="form-group">
            <label htmlFor="soDienThoai">Số điện thoại</label>
            <input
              type="text"
              id="soDienThoai"
              name="soDienThoai"
              value={formData.soDienThoai}
              onChange={handleChange}
              className={errors.soDienThoai ? 'error' : ''}
            />
            {errors.soDienThoai && <span className="error-message">{errors.soDienThoai}</span>}
          </div>
          
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              className={errors.email ? 'error' : ''}
            />
            {errors.email && <span className="error-message">{errors.email}</span>}
          </div>
        </div>
        
        <div className="form-actions">
          <button type="submit" className="btn-primary">
            {editingStudent ? 'Cập nhật sinh viên' : 'Thêm sinh viên'}
          </button>
          {editingStudent && (
            <button type="button" className="btn-secondary" onClick={handleCancel}>
              Hủy
            </button>
          )}
        </div>
      </form>
    </div>
  )
}

export default StudentForm
