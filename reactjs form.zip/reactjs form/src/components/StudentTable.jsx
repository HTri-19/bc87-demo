import { useDispatch, useSelector } from 'react-redux'
import { deleteStudent, setEditingStudent } from '../store/studentSlice'

const StudentTable = () => {
  const dispatch = useDispatch()
  const { students, searchTerm } = useSelector(state => state.students)
  
  // Filter students based on search term
  const filteredStudents = students.filter(student => {
    if (!searchTerm) return true
    
    const searchLower = searchTerm.toLowerCase()
    return (
      student.maSV.toLowerCase().includes(searchLower) ||
      student.hoTen.toLowerCase().includes(searchLower) ||
      student.soDienThoai.toLowerCase().includes(searchLower) ||
      student.email.toLowerCase().includes(searchLower)
    )
  })

  const handleEdit = (student) => {
    dispatch(setEditingStudent(student))
  }

  const handleDelete = (id) => {
    if (window.confirm('Bạn có chắc chắn muốn xóa sinh viên này?')) {
      dispatch(deleteStudent(id))
    }
  }

  return (
    <div className="student-table">
      <table>
        <thead>
          <tr>
            <th>Mã SV</th>
            <th>Họ tên</th>
            <th>Số điện thoại</th>
            <th>Email</th>
            <th>Thao tác</th>
          </tr>
        </thead>
        <tbody>
          {filteredStudents.length === 0 ? (
            <tr>
              <td colSpan="5" className="no-data">
                {searchTerm ? 'Không tìm thấy sinh viên nào' : 'Chưa có sinh viên nào'}
              </td>
            </tr>
          ) : (
            filteredStudents.map((student) => (
              <tr key={student.id}>
                <td>{student.maSV}</td>
                <td>{student.hoTen}</td>
                <td>{student.soDienThoai}</td>
                <td>{student.email}</td>
                <td className="actions">
                  <button 
                    className="btn-edit"
                    onClick={() => handleEdit(student)}
                    title="Chỉnh sửa"
                  >
                    Sửa
                  </button>
                  <button 
                    className="btn-delete"
                    onClick={() => handleDelete(student.id)}
                    title="Xóa"
                  >
                    Xóa
                  </button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
      
      {filteredStudents.length > 0 && (
        <div className="table-info">
          Hiển thị {filteredStudents.length} sinh viên
          {searchTerm && ` (tìm kiếm: "${searchTerm}")`}
        </div>
      )}
    </div>
  )
}

export default StudentTable
