import Glasses from "./glasses/glasses";

function App() {
  return (
    <>
      <Glasses />
    </>
  );
}

export default App;
