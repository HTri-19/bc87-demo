import { useState } from "react";

export default function Glasses() {
  const [imgUrl, setImgUrl] = useState("/img/v1.png");

  const glassesList = [
    "v1.png",
    "v2.png",
    "v3.png",
    "v4.png",
    "v5.png",
    "v6.png",
    "v7.png",
    "v8.png",
    "v9.png",
  ];

  return (
    <div>
      <h1 style={{ textAlign: "center", margin: "20px 0" }}>Glasses App</h1>

      {/* Background */}
      <div
        style={{
          position: "relative",
          backgroundImage: `url(/img/background.jpg)`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          minHeight: "100vh",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        {/* Model */}
        <div style={{ position: "relative" }}>
          <img src="/img/model.jpg" alt="model" width={300} />

          {/* Glasses overlay */}
          <img
            src={imgUrl}
            alt="glasses"
            style={{
              position: "absolute",
              top: "90px",
              left: "65px",
              width: "170px",
              opacity: 0.8,
            }}
          />
        </div>
      </div>

      {/* List glasses */}
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          flexWrap: "wrap",
          gap: "10px",
          marginTop: "20px",
        }}
      >
        {glassesList.map((item, index) => (
          <button
            key={index}
            style={{
              width: "100px",
              height: "60px",
              backgroundImage: `url(/img/${item})`,
              backgroundSize: "contain",
              backgroundRepeat: "no-repeat",
              backgroundPosition: "center",
              border: "1px solid #ccc",
              borderRadius: "5px",
              cursor: "pointer",
            }}
            onClick={() => setImgUrl(`/img/${item}`)}
          ></button>
        ))}
      </div>
    </div>
  );
}
