let numbers = [];

function updateArrayDisplay() {
  document.getElementById("arrayDisplay").innerText =
    "👉 Mảng hiện tại: [" + numbers.join(", ") + "]";
}

function addNumber() {
  const value = Number(document.getElementById("inputNumber").value);
  numbers.push(value);
  updateArrayDisplay();
  document.getElementById("inputNumber").value = "";
}

// 1. Tổng số dương
function sumPositive() {
  let sum = numbers.filter((n) => n > 0).reduce((a, b) => a + b, 0);
  document.getElementById("result1").innerText = "Tổng số dương là: " + sum;
}

// 2. Đếm số dương
function countPositive() {
  let count = numbers.filter((n) => n > 0).length;
  document.getElementById("result2").innerText = "Có " + count + " số dương";
}

// 3. Tìm số nhỏ nhất
function findMin() {
  let min = Math.min(...numbers);
  document.getElementById("result3").innerText = "Số nhỏ nhất là: " + min;
}

// 4. Tìm số dương nhỏ nhất
function findMinPositive() {
  let d = numbers.filter((n) => n > 0);
  let min = d.length ? Math.min(...d) : "Không có số dương";
  document.getElementById("result4").innerText = "Số dương nhỏ nhất là: " + min;
}

// 5. Tìm số chẵn cuối cùng
function findLastEven() {
  let last = -1;
  for (let i = numbers.length - 1; i >= 0; i--) {
    if (numbers[i] % 2 === 0) {
      last = numbers[i];
      break;
    }
  }
  document.getElementById("result5").innerText =
    "Số chẵn cuối cùng: " + (last !== -1 ? last : "Không có");
}

// 6. Đổi chỗ
function swapPositions() {
  const i = Number(document.getElementById("pos1").value);
  const j = Number(document.getElementById("pos2").value);
  if (i >= 0 && j >= 0 && i < numbers.length && j < numbers.length) {
    [numbers[i], numbers[j]] = [numbers[j], numbers[i]];
    updateArrayDisplay();
    document.getElementById("result6").innerText = `Đã đổi vị trí ${i} và ${j}`;
  } else {
    document.getElementById("result6").innerText = "Vị trí không hợp lệ";
  }
}

// 7. Sắp xếp tăng dần
function sortArray() {
  numbers.sort((a, b) => a - b);
  updateArrayDisplay();
  document.getElementById("result7").innerText = "Mảng đã sắp xếp tăng dần";
}

// 8. Tìm số nguyên tố đầu tiên
function isPrime(n) {
  if (n < 2) return false;
  for (let i = 2; i <= Math.sqrt(n); i++) if (n % i === 0) return false;
  return true;
}

function findFirstPrime() {
  let prime = numbers.find((n) => isPrime(n));
  document.getElementById("result8").innerText =
    "Số nguyên tố đầu tiên: " + (prime !== undefined ? prime : "Không có");
}

// 9. Đếm số nguyên
function countIntegers() {
  let count = numbers.filter((n) => Number.isInteger(n)).length;
  document.getElementById("result9").innerText = "Số lượng số nguyên: " + count;
}

// 10. So sánh số dương và âm
function comparePositiveNegative() {
  let pos = numbers.filter((n) => n > 0).length;
  let neg = numbers.filter((n) => n < 0).length;
  let result =
    pos > neg
      ? "Nhiều số dương hơn"
      : pos < neg
      ? "Nhiều số âm hơn"
      : "Số âm và dương bằng nhau";
  document.getElementById("result10").innerText = result;
}
